import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const someFunction: () => string;
//# sourceMappingURL=index.d.ts.map